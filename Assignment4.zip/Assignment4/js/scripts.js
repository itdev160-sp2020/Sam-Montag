// welcome message
var user = 'Sam';
var salutation = 'Greetings, ';
var greeting = salutation + user + '! Here are the latest Rainbow Six reviews.';
var greetingEl = document.getElementById('greeting');

greetingEl.textContent = greeting;

// product price
var price = 60,
    saleDiscount = .50,
    salePrice = price - (price * saleDiscount),
    priceEl = document.getElementById('price'),
    salePriceEl = document.getElementById('sale-price');

priceEl.textContent = price.toFixed(2);
salePriceEl.textContent = salePrice.toFixed(2);