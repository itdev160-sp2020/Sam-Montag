(function() {

    var data= [
        {
            name: "emmet",
            description: "Emmet is the number one code snippet tool.",
            author: "emmetio",
            url: "https://atom.io/packages/emmet",
            downloads: 1662209,
            stars: 2534,
            price: 10.50,
            selector: "p1"
        }
    ];
    
    function Package(data) {
        this.name = data.name;
        this.description = data.description;
        this.author = data.author;
        this.url = data.url;
        this.downloads = data.downloads;
        this.stars = data.stars;
        this.selector = data.selector;
    
        this.getFormattedDownloads = function () {
            return this.downloads.toLocaleString();
        };
    
        this.getFormattedStars = function () {
            return this.stars.toLocaleString();
        };
    }
    
    var getTodaysDate = function() {
        var today = new Date();
        return today.toDateString();
    };
    
    var getEl = function (id) {
        return document.getElementById(id);
    }
    
    var writePackageInfo = function(package) {
        var selector = package.selector,
            nameEl = getEl(selector + "-name"),
            descEl = getEl(selector + "-description"),
            authEl = getEl(selector + "-author"),
            downloadEl = getEl(selector + "-downloads"),
            starsEl = getEl(selector + "-stars");
    
            nameEl.textContent = package.name;
            descEl.textContent = package.description;
            authEl.textContent = package.author;
            downloadEl.textContent = package.getFormattedDownloads();
            starsEl.textContent = package.getFormattedStars();
    }
    
    dateEl = getEl("date");
    dateEl.textContent = getTodaysDate();
    
    var emmet = new Package(data[0]);
    writePackageInfo(emmet);
    
    var data2= [
        {
            name: "autoclosehtml",
            description: "Autoclose-html-plus automatically closes HTML tags for you!",
            author: "binaryfunt",
            url: "https://atom.io/packages/autoclose-html-plus",
            downloads: 15375,
            stars: 2,
            price: 0000,
            selector: "p2"
        }
    ];
    
    function Package(data2) {
        this.name = data2.name;
        this.description = data2.description;
        this.author = data2.author;
        this.url = data2.url;
        this.downloads = data2.downloads;
        this.stars = data2.stars;
        this.selector = data2.selector;
    
        this.getFormattedDownloads = function () {
            return this.downloads.toLocaleString();
        };
    
        this.getFormattedStars = function () {
            return this.stars.toLocaleString();
        };
    }
    
    var getTodaysDate = function() {
        var today = new Date();
        return today.toDateString();
    };
    
    var getEl = function (id) {
        return document.getElementById(id);
    }
    
    var writePackageInfo = function(package) {
        var selector = package.selector,
            nameEl = getEl(selector + "-name"),
            descEl = getEl(selector + "-description"),
            authEl = getEl(selector + "-author"),
            downloadEl = getEl(selector + "-downloads"),
            starsEl = getEl(selector + "-stars");
    
            nameEl.textContent = package.name;
            descEl.textContent = package.description;
            authEl.textContent = package.author;
            downloadEl.textContent = package.getFormattedDownloads();
            starsEl.textContent = package.getFormattedStars();
    }
    
    dateEl = getEl("date");
    dateEl.textContent = getTodaysDate();

    var autoclosehtml = new Package(data2[0]);
    writePackageInfo(autoclosehtml);

    var data3= [
        {
            name: "pigments",
            description: "Pigments displays colors within project files, which is super"
                            + "helpful in determining what a hex code might be.",
            author: "abe33",
            url: "https://atom.io/packages/pigments",
            downloads: 3000416,
            stars: 3701,
            price: 0000,
            selector: "p3"
        }
    ];
    
    function Package(data3) {
        this.name = data3.name;
        this.description = data3.description;
        this.author = data3.author;
        this.url = data3.url;
        this.downloads = data3.downloads;
        this.stars = data3.stars;
        this.selector = data3.selector;
    
        this.getFormattedDownloads = function () {
            return this.downloads.toLocaleString();
        };
    
        this.getFormattedStars = function () {
            return this.stars.toLocaleString();
        };
    }
    
    var getTodaysDate = function() {
        var today = new Date();
        return today.toDateString();
    };
    
    var getEl = function (id) {
        return document.getElementById(id);
    }
    
    var writePackageInfo = function(package) {
        var selector = package.selector,
            nameEl = getEl(selector + "-name"),
            descEl = getEl(selector + "-description"),
            authEl = getEl(selector + "-author"),
            downloadEl = getEl(selector + "-downloads"),
            starsEl = getEl(selector + "-stars");
    
            nameEl.textContent = package.name;
            descEl.textContent = package.description;
            authEl.textContent = package.author;
            downloadEl.textContent = package.getFormattedDownloads();
            starsEl.textContent = package.getFormattedStars();
    }
    
    dateEl = getEl("date");
    dateEl.textContent = getTodaysDate();

    var pigments = new Package(data3[0]);
    writePackageInfo(pigments);
    
    }());
    